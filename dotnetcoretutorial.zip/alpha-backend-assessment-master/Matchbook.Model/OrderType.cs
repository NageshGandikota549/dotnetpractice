﻿namespace Matchbook.Model
{
    public enum OrderType
    { 
        EFP, 
        EFR, 
        InternalTransfer, 
        InternalBookTransfer, 
        BackOfficeTransfer 
    }
}
